#import <Foundation/Foundation.h>

@class KUPUpPresenter;

@protocol KUPIUpManager, KUPIUpPresenter, KUPIUpView;

NS_ASSUME_NONNULL_BEGIN

@interface KotlinBase : NSObject
-(instancetype) init __attribute__((unavailable));
+(instancetype) new __attribute__((unavailable));
+(void)initialize __attribute__((objc_requires_super));
@end;

@protocol KUPIUpManager
@required
-(NSString*)getString NS_SWIFT_NAME(getString());
@end;

@protocol KUPIUpPresenter
@required
-(void)setViewView:(id<KUPIUpView>)view NS_SWIFT_NAME(setView(view:));
-(void)buttonPressed NS_SWIFT_NAME(buttonPressed());
@end;

@protocol KUPIUpView
@required
-(void)displayDisplayMe:(NSString*)displayMe NS_SWIFT_NAME(display(displayMe:));
@end;

__attribute__((objc_subclassing_restricted))
@interface KUPUpPresenter : KotlinBase <KUPIUpPresenter>
-(instancetype)initWithUpManager:(id<KUPIUpManager>)upManager NS_SWIFT_NAME(init(upManager:)) NS_DESIGNATED_INITIALIZER;

@property (readonly) id<KUPIUpManager> upManager;
@end;

NS_ASSUME_NONNULL_END
